path(path,'/afs/eos/info/ie/ie589k_info/GAOT');

