#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <vector>

#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>                

#include <geometry_msgs/Vector3.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>

#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

using namespace std;
using namespace cv;

ros::Publisher * vo_pub_ptr;
tf::TransformBroadcaster * vo_broadcaster_ptr;

ros::Time current_time, last_time;
double last_time_pub = 0.0;

// Dummy values for covariance BUT 
// these need to be provided VERY carefully

double cov_x = 0.0015;
double cov_y = 0.0024;
double cov_z = 0.0;
double cov_thX = 99999;
double cov_thY = 99999;
double cov_thZ = 0.05;

//Receive VO X,Y T Position and send 'vo' and 'tf'
void publishVoData(double vo_X, double vo_Y, double vo_T)
	{ 

        current_time = ros::Time::now(); 
	
	// Publish the VO message over ROS
        nav_msgs::Odometry vo;
        vo.header.stamp = current_time;
        vo.header.frame_id = "vo";
            
        // Set the position
        vo.pose.pose.position.x = vo_X;	//x measurement VO
        vo.pose.pose.position.y = vo_Y;	//y measurement VO
        vo.pose.pose.position.z = 0.0;		//z measurement VO
        vo.pose.pose.orientation.x = 0; 	//identity quaternion
	vo.pose.pose.orientation.y = 0;	//identity quaternion
	vo.pose.pose.orientation.z = vo_T;   	//identity quaternion
	vo.pose.pose.orientation.w = 0; 	//identity quaternion

	vo.pose.covariance = 	{cov_x, 0, 0, 0, 0, 0,  // covariance on vo_x
                        	0, cov_y, 0, 0, 0, 0,  	// covariance on vo_y
                        	0, 0, cov_z, 0, 0, 0,  	// covariance on vo_z
                        	0, 0, 0, cov_thX, 0, 0,  // large covariance on rot x
                        	0, 0, 0, 0, cov_thY, 0,  // large covariance on rot y
                        	0, 0, 0, 0, 0, cov_thZ}; // large covariance on rot z          
       
        // Publish the message        
        vo_pub_ptr->publish(vo);            // VO odometry publisher 
        ros::spinOnce();    
	}

int main(int argc, char** argv){
  
        ros::init(argc, argv, "VO_Loc");
        ros::NodeHandle n;
        ros::NodeHandle pn("~");
                
        // ROS publishers and subscribers
        ros::Publisher vo_pub = n.advertise<nav_msgs::Odometry>("/vo", 100);
        tf::TransformBroadcaster vo_broadcaster;
    
        vo_pub_ptr = &vo_pub;
        vo_broadcaster_ptr = &vo_broadcaster;       
        
        // -------------------------------------------//

	VideoCapture cap(0); // open the default camera
    		if(!cap.isOpened())  // check if we succeeded
        	return -1;

    	Mat edges;
    	namedWindow("edges",1);
    	for(;;)
    	{
        	Mat frame;
        	cap >> frame; // get a new frame from camera
        	cvtColor(frame, edges, CV_BGR2GRAY);
        	imshow("edges", edges);

		// Call the publisher
	//	publishVoData (X, Y, T);
		publishVoData (10, 5.0, 1.0); // this is an example

        	if(waitKey(30) == 'q') break;
    	}

	//---------------------------------------------//

        ros::spin(); //trigger callbacks and prevents exiting
        return(0);
}
