#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <vector>

#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>           

#include <geometry_msgs/Vector3.h>
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>

ros::Publisher * vo_pub_ptr;
tf::TransformBroadcaster * vo_broadcaster_ptr;

ros::Time current_time, last_time;

// Dummy values for covariance
double cov_x = 0.0015;
double cov_y = 0.0024;
double cov_z = 0.0;
double cov_thX = 99999;
double cov_thY = 99999;
double cov_thZ = 0.05;	

void fakeVoCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
  
        current_time = ros::Time::now();       
            
        // Publish the VO message over ROS
        nav_msgs::Odometry vo;
        vo.header.stamp = msg->header.stamp;
        vo.header.frame_id = "vo_fake";
            
        // Set the position
        vo.pose.pose.position.x = msg->pose.pose.position.x;
        vo.pose.pose.position.y = msg->pose.pose.position.y;
        vo.pose.pose.position.z = msg->pose.pose.position.z;
        vo.pose.pose.orientation.x = msg->pose.pose.orientation.x; 
		vo.pose.pose.orientation.y = msg->pose.pose.orientation.y;
		vo.pose.pose.orientation.z = msg->pose.pose.orientation.z;
		vo.pose.pose.orientation.w = msg->pose.pose.orientation.w;
 
	  vo.pose.covariance = {cov_x, 0, 0, 0, 0, 0,  // covariance on vo_x
                        	0, cov_y, 0, 0, 0, 0,  	// covariance on vo_y
                        	0, 0, cov_z, 0, 0, 0,  	// covariance on vo_z
                        	0, 0, 0, cov_thX, 0, 0,  	// large covariance on rot x
                        	0, 0, 0, 0, cov_thY, 0,  	// large covariance on rot y
                        	0, 0, 0, 0, 0, cov_thZ}; 	// large covariance on rot z          
       
	// Set the velocity
        vo.child_frame_id = "base_link";
        vo.twist.twist.linear.x = msg->twist.twist.linear.x;
        vo.twist.twist.linear.y = 0.0;
        vo.twist.twist.angular.z = msg->twist.twist.angular.z;  
      
	// Publish the message        
        vo_pub_ptr->publish(vo);            // vo publisher 
        ros::spinOnce();    
}

int main(int argc, char** argv){
  
        ros::init(argc, argv, "VO_Loc_Fake");
        ros::NodeHandle n;
        
         // ROS publishers and subscribers
	ros::Subscriber odom_sub = n.subscribe("odom", 100, fakeVoCallback);

        ros::Publisher vo_pub = n.advertise<nav_msgs::Odometry>("/vo_fake", 100);
        tf::TransformBroadcaster vo_broadcaster;
    
        vo_pub_ptr = &vo_pub;
        vo_broadcaster_ptr = &vo_broadcaster;        
            
        ros::spin(); 
        return(0);
}
